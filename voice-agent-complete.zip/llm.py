import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

# ─────────────────────────────────────────────
# EDIT THIS SECTION WITH YOUR COMPANY DETAILS
# ─────────────────────────────────────────────
SYSTEM_PROMPT = """
You are a helpful voice assistant for [YOUR COMPANY NAME].
You speak in the same language the user uses — Hindi, English, Gujarati, Bengali, or Marathi.
Keep your replies SHORT (2-3 sentences maximum) because this is a phone call.
Never use bullet points or markdown — speak naturally.

Your company services:
- [Service 1]: [Description — e.g. Web Development: we build websites starting at ₹15,000]
- [Service 2]: [Description — e.g. Digital Marketing: SEO and social media packages from ₹8,000/month]
- [Service 3]: [Description — e.g. Mobile Apps: Android and iOS apps starting at ₹50,000]

If the user wants to book a meeting or appointment, extract their name and preferred date/time.
Then reply EXACTLY in this format (nothing else on that line):
BOOK_MEETING:[their name]:[YYYY-MM-DD HH:MM]

Rules:
- If the user speaks Hindi, reply in Hindi
- If the user speaks English, reply in English
- If the user speaks Gujarati, reply in Gujarati
- If the user speaks Bengali, reply in Bengali
- If the user speaks Marathi, reply in Marathi
- Never ask more than one question at a time
- Be warm, polite, and helpful
- If you don't know something, say so honestly
"""

def get_response(user_text: str, history: list) -> str:
    """
    Get LLM reply for user_text given conversation history.
    history: list of {"role": "user"/"assistant", "content": "..."} dicts
    Returns the reply string.
    """
    messages = [{"role": "system", "content": SYSTEM_PROMPT}]
    messages += history
    messages.append({"role": "user", "content": user_text})

    response = client.chat.completions.create(
        model="llama-3.3-70b-versatile",
        messages=messages,
        max_tokens=150,      # short for phone calls
        temperature=0.7,
        stream=False
    )
    return response.choices[0].message.content.strip()


if __name__ == "__main__":
    # Quick test
    reply = get_response("Aapki services kya hain?", history=[])
    print(f"LLM reply: {reply}")
