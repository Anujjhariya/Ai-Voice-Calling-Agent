import os
import tempfile
import requests
from flask import Flask, request, Response, send_file
import plivo
from dotenv import load_dotenv

from stt import transcribe_audio
from llm import get_response
from tts import text_to_speech
from lang_detect import detect_language
from calendar_api import book_meeting

load_dotenv()

app = Flask(__name__)

# Store conversation history per call (keyed by CallUUID)
call_history = {}

# Your public server URL (update after deploying)
# For local testing: use your ngrok URL e.g. https://abc123.ngrok.io
BASE_URL = os.getenv("BASE_URL", "http://localhost:5000")


# ─────────────────────────────────────────────
# ROUTE 1: Incoming call — greet the user
# ─────────────────────────────────────────────
@app.route("/answer", methods=["GET", "POST"])
def answer_call():
    """Called by Plivo when someone calls your number."""
    response = plivo.XML.Response()

    # Greet in Hindi (first message)
    response.addSpeak(
        "Namaste! Main aapki kaise madad kar sakta hoon? "
        "Aap Hindi, English, ya kisi bhi bhasha mein baat kar sakte hain.",
        language="hi-IN"
    )

    # Record the user's speech (up to 8 seconds)
    record_params = {
        "action": f"{BASE_URL}/process_speech",
        "method": "POST",
        "maxLength": "8",
        "finishOnKey": "#",
        "recordSession": "false",
        "redirect": "true"
    }
    response.addRecord(**record_params)

    return Response(str(response), mimetype="text/xml")


# ─────────────────────────────────────────────
# ROUTE 2: Process the recorded speech
# ─────────────────────────────────────────────
@app.route("/process_speech", methods=["GET", "POST"])
def process_speech():
    """Called by Plivo after recording the user's speech."""
    call_uuid = request.form.get("CallUUID", "unknown")
    recording_url = request.form.get("RecordingUrl", "")

    if not recording_url:
        # No audio received — ask again
        response = plivo.XML.Response()
        response.addSpeak("Mujhe aapki awaaz nahi aayi. Kripya dobara bolein.")
        response.addRecord(
            action=f"{BASE_URL}/process_speech",
            method="POST",
            maxLength="8"
        )
        return Response(str(response), mimetype="text/xml")

    # ── Step 1: Download the audio ──
    audio_resp = requests.get(recording_url, auth=(
        os.getenv("PLIVO_AUTH_ID"),
        os.getenv("PLIVO_AUTH_TOKEN")
    ))
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as tmp:
        tmp.write(audio_resp.content)
        audio_path = tmp.name

    # ── Step 2: Transcribe (STT) ──
    try:
        user_text = transcribe_audio(audio_path, language="hi")
    except Exception as e:
        user_text = ""
        print(f"STT error: {e}")

    if not user_text.strip():
        response = plivo.XML.Response()
        response.addSpeak("Kripya thoda aur zyada bol kar dobara bolein.")
        response.addRecord(action=f"{BASE_URL}/process_speech", method="POST", maxLength="8")
        return Response(str(response), mimetype="text/xml")

    # ── Step 3: Detect language ──
    lang_info = detect_language(user_text)
    lang_code = lang_info["groq_lang"]
    print(f"[{call_uuid}] User ({lang_info['name']}): {user_text}")

    # ── Step 4: Get LLM reply ──
    history = call_history.get(call_uuid, [])
    try:
        reply_text = get_response(user_text, history)
    except Exception as e:
        reply_text = "Maafi chahta hoon, abhi thodi takleef ho rahi hai. Kripya baad mein call karein."
        print(f"LLM error: {e}")

    print(f"[{call_uuid}] Agent ({lang_info['name']}): {reply_text}")

    # ── Step 5: Check for meeting booking ──
    if "BOOK_MEETING:" in reply_text:
        try:
            parts = reply_text.split(":")
            # parts = ["BOOK_MEETING", name, "YYYY-MM-DD HH", "MM"]
            name = parts[1].strip()
            dt_str = parts[2].strip() + ":" + parts[3].strip()
            confirmation = book_meeting(name, dt_str)
            reply_text = confirmation
            print(f"[{call_uuid}] Meeting booked: {confirmation}")
        except Exception as e:
            reply_text = "Meeting book nahi ho saki. Kripya phir se try karein."
            print(f"Calendar error: {e}")

    # ── Step 6: Update conversation history ──
    history.append({"role": "user", "content": user_text})
    history.append({"role": "assistant", "content": reply_text})
    call_history[call_uuid] = history[-10:]  # keep last 10 turns only

    # ── Step 7: Convert reply to audio (TTS) ──
    audio_filename = f"reply_{call_uuid}.mp3"
    audio_output_path = os.path.join(tempfile.gettempdir(), audio_filename)
    try:
        text_to_speech(reply_text, lang_code=lang_code, output_path=audio_output_path)
    except Exception as e:
        # Fallback: use Plivo's built-in TTS
        print(f"TTS error: {e}")
        response = plivo.XML.Response()
        response.addSpeak(reply_text)
        response.addRecord(action=f"{BASE_URL}/process_speech", method="POST", maxLength="8")
        return Response(str(response), mimetype="text/xml")

    # ── Step 8: Play audio and listen for next input ──
    response = plivo.XML.Response()
    response.addPlay(f"{BASE_URL}/audio/{audio_filename}")
    response.addRecord(
        action=f"{BASE_URL}/process_speech",
        method="POST",
        maxLength="8",
        finishOnKey="#"
    )

    return Response(str(response), mimetype="text/xml")


# ─────────────────────────────────────────────
# ROUTE 3: Serve audio files
# ─────────────────────────────────────────────
@app.route("/audio/<filename>")
def serve_audio(filename):
    """Serve generated TTS audio files to Plivo."""
    audio_path = os.path.join(tempfile.gettempdir(), filename)
    if os.path.exists(audio_path):
        return send_file(audio_path, mimetype="audio/mpeg")
    return "File not found", 404


# ─────────────────────────────────────────────
# ROUTE 4: Health check
# ─────────────────────────────────────────────
@app.route("/health")
def health():
    return {"status": "running", "agent": "voice-agent-v1"}, 200


if __name__ == "__main__":
    print("=" * 50)
    print("Voice Agent starting on http://localhost:5000")
    print("For local testing, run: ngrok http 5000")
    print("Then set BASE_URL in your .env to your ngrok URL")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True)
