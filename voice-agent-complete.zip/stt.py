import os
from groq import Groq
from dotenv import load_dotenv

load_dotenv()
client = Groq(api_key=os.getenv("GROQ_API_KEY"))

def transcribe_audio(audio_file_path: str, language: str = "hi") -> str:
    """
    Transcribe audio using Groq Whisper large-v3-turbo.
    - audio_file_path: path to .wav or .mp3 file
    - language: hint for accuracy (hi / en / gu / bn / mr)
    Returns plain transcribed text string.
    """
    with open(audio_file_path, "rb") as f:
        transcription = client.audio.transcriptions.create(
            model="whisper-large-v3-turbo",
            file=f,
            language=language,
            response_format="text"
        )
    return transcription.strip()


if __name__ == "__main__":
    # Quick test — replace with a real audio file path
    result = transcribe_audio("test.wav", language="hi")
    print(f"Transcribed: {result}")
