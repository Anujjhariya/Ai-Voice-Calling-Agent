# AI Voice Calling Agent

A multilingual AI voice agent built in Python. Handles calls in Hindi, English, Gujarati, Bengali, and Marathi. Books meetings via Google Calendar.

## Stack (all free/very cheap)
- **STT**: Groq Whisper (free tier — 2000 calls/day)
- **LLM**: Groq Llama 3.3 70B (free tier)
- **TTS**: Murf Falcon ($0.01/min — $10 free credit)
- **Telephony**: Plivo (free credit on signup)
- **Calendar**: Google Calendar API (free)
- **Hosting**: Railway (free tier)

## Setup

### 1. Install dependencies
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 2. Configure environment
```bash
cp .env.example .env
# Edit .env with your API keys
```

### 3. Set up Google Calendar (one-time)
```bash
# Place your credentials.json in the project root, then:
python calendar_api.py
# A browser window opens — authorize access
```

### 4. Edit your company info
Open `llm.py` and edit the `SYSTEM_PROMPT` section with your company name and services.

### 5. Run locally
```bash
# Terminal 1:
python main.py

# Terminal 2:
ngrok http 5000
# Copy the ngrok URL (e.g. https://abc123.ngrok.io)
```

### 6. Configure Plivo
- Go to plivo.com → Phone Numbers → Your Number
- Set **Answer URL** to: `https://abc123.ngrok.io/answer`
- Set **HTTP Method** to: `POST`

### 7. Test — call your Plivo number!

## Deploy to production (Railway)
```bash
git init && git add . && git commit -m "voice agent"
# Push to GitHub, then connect repo on railway.app
# Add all .env variables in Railway dashboard
# Update BASE_URL in Railway to your Railway public URL
# Update Plivo Answer URL to your Railway URL
```

## File structure
```
voice-agent/
├── main.py          # Flask app + Plivo webhooks
├── stt.py           # Groq Whisper transcription
├── llm.py           # Groq Llama conversation
├── tts.py           # Murf Falcon text-to-speech
├── calendar_api.py  # Google Calendar booking
├── lang_detect.py   # Auto language detection
├── .env             # Your API keys (never commit!)
├── .env.example     # Template
└── requirements.txt
```

## Estimated cost
| Volume | Cost/month |
|--------|-----------|
| < 2000 calls/day | ~$0 (all free tiers) |
| 1000 min/month TTS | ~$10 (Murf Falcon) |
| Heavy usage | ~$20-40 |
