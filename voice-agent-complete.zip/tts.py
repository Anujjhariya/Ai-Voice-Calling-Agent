import os
import requests
from dotenv import load_dotenv

load_dotenv()
MURF_API_KEY = os.getenv("MURF_API_KEY")

# Map language code → Murf Falcon voice ID
# Visit murf.ai/api to see all available Indian voices
VOICE_MAP = {
    "hi": "hi-IN-aarav",       # Hindi male
    "en": "en-IN-rohan",       # Indian English male
    "gu": "gu-IN-voice-1",     # Gujarati (check murf.ai for exact ID)
    "bn": "bn-IN-voice-1",     # Bengali (check murf.ai for exact ID)
    "mr": "mr-IN-voice-1",     # Marathi (check murf.ai for exact ID)
}

def text_to_speech(text: str, lang_code: str = "hi", output_path: str = "response.mp3") -> str:
    """
    Convert text to speech using Murf Falcon API.
    - text: the reply text to speak
    - lang_code: hi / en / gu / bn / mr
    - output_path: where to save the mp3
    Returns the output file path.
    """
    voice_id = VOICE_MAP.get(lang_code, "hi-IN-aarav")

    url = "https://api.murf.ai/v1/speech/generate"
    headers = {
        "api-key": MURF_API_KEY,
        "Content-Type": "application/json"
    }
    payload = {
        "voiceId": voice_id,
        "text": text,
        "style": "Conversational",
        "modelVersion": "GEN2",   # Murf Falcon model
        "format": "MP3",
        "sampleRate": 24000
    }

    resp = requests.post(url, json=payload, headers=headers)
    resp.raise_for_status()

    data = resp.json()
    audio_url = data.get("audioFile") or data.get("audio_file")

    # Download the generated audio
    audio_data = requests.get(audio_url)
    with open(output_path, "wb") as f:
        f.write(audio_data.content)

    return output_path


if __name__ == "__main__":
    # Quick test
    path = text_to_speech("Namaste! Aapka swagat hai.", lang_code="hi")
    print(f"Audio saved to: {path}")
